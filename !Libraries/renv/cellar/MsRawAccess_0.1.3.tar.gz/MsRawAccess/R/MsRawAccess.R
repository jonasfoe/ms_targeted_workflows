#' MsRawAccess
#'
#' Access Theromo R files from R
#'
#' @import assertthat
#' @importFrom methods getPackageName
"_PACKAGE"

pkg_env <- new.env(parent = emptyenv())
pkg_env$license_accepted <- FALSE

.onLoad <- function(libname, pkgname) {
  if (check_license_accepted_env())
    try(accept_license())

  if (!check_license_accepted() && interactive()) {
    print_license()
    message("To use MsRawAccess, please accept the stated license for the Thermo RawFileReader by calling 'MsRawAccess::accept_license()' once on your system")
  }

  if (.Platform$OS.type != "windows" && processx::run("dotnet", "--info")$status != 0) {
    warning("MsRawAccess requires the the command 'dotnet'. You must install the .NET runtime: https://dotnet.microsoft.com/en-us/download/dotnet/6.0")
  }
}

to_df <- function(out_list) {
  data.frame(out_list, row.names = NULL, check.rows = FALSE, check.names = FALSE, fix.empty.names = FALSE, stringsAsFactors = FALSE)
}

base64_encode <- function(x) {
  base64enc::base64encode(writeBin(x, raw()))
}

base64_decode <- function(char, what, size) {
  raw_vec <- base64enc::base64decode(char)
  readBin(raw_vec, what = what, n = length(raw_vec) / size, size = size)
}

start_std_process <- function(filepath, cmd, args = character()) {
  if (.Platform$OS.type == "windows") {
    # on windows, let the .exe handle looking up the framework
    command <- system.file("exec_ext", "rawfile_cli_base64.exe", package = getPackageName())
    pre_arg <- character()
  } else {
    # everywhere else, expect the dotnet command
    command <- "dotnet"
    pre_arg <- system.file("exec_ext", "rawfile_cli_base64.dll", package = getPackageName())
  }

  processx::process$new(
    command = command,
    args = c(
      pre_arg,
      cmd,
      normalizePath(filepath),
      args,
      "--accept-license"
    ),
    stdin = "|",
    stdout = "|",
    stderr = "|",
    encoding = "UTF-8"
  )
}

# get_process_list_output <- function(process) {
#   stdout_list <- list()
#
#   while (process$is_incomplete_output()) {
#     process$poll_io(timeout = -1)
#
#     for (line in process$read_output_lines()) {
#       x <- stringr::str_split_fixed(line, stringr::coll("\t"), 4)
#
#       stopifnot(all(x[1:3] != ""))
#
#       if (x[2] == "na_mask") {
#         stdout_list[[x[1]]] <- replace(stdout_list[[x[1]]], !base64_decode(x[4], what = "logical", size = as.numeric(x[3])), NA)
#       } else if (x[2] == "string") {
#         stdout_list[[x[1]]] <- stringr::str_replace_all(stringr::str_split(x[4], stringr::coll("\t"))[[1]], stringr::coll("\\t"), "\t")
#       } else if (x[2] == "date") {
#         # date is scalar for now
#         date_parts <- stringr::str_split_fixed(x[4], stringr::coll(" "), n = 3)
#         stdout_list[[x[1]]] <- strptime(paste(date_parts[1], date_parts[2]), format = "%Y-%m-%dT%H:%M:%S", tz = date_parts[3])
#       } else {
#         stdout_list[[x[1]]] <- base64_decode(x[4], what = x[2], size = as.numeric(x[3]))
#       }
#     }
#   }
#
#   errors <- process$read_all_error_lines()
#   if (length(errors) != 0)
#     stop(stringr::str_c("\n", errors, collapse = "\n\n"))
#
#   stdout_list
# }

data_types <- list(
  Bool = list(type = "logical", size = 1),
  Int32 = list(type = "integer", size = 4),
  Float32 = list(type = "numeric", size = 4),
  Float64 = list(type = "numeric", size = 8)
)

get_process_list_output <- function(process) {
  stdout_list <- list()

  tryCatch(
    {
      while (process$is_incomplete_output()) {
        process$poll_io(timeout = 10)

        for (line in process$read_output_lines()) {
          x <- stringr::str_split_fixed(line, stringr::coll("\t"), 4)

          stopifnot(all(x[1:3] != ""))

          # R doesnt care if scalar or vector for now
          if (x[2] == "scalar" || x[2] == "vector") {
            if (x[3] == "na_mask") {
              stdout_list[[x[1]]] <- replace(stdout_list[[x[1]]], !base64_decode(x[4], what = "logical", size = 1), NA)
            } else if (x[3] == "String") {
              stdout_list[[x[1]]] <- stringr::str_replace_all(stringr::str_split(x[4], stringr::coll("\t"))[[1]], stringr::coll("\\t"), "\t")
            } else if (x[3] == "Date") {
              # date is scalar for now
              date_trunc <- stringr::str_extract(x[4], "^(.*)(?<=\\+00:00)$")
              stopifnot(!is.na(date_trunc))
              stdout_list[[x[1]]] <- as.POSIXct(strptime(date_trunc, format = "%Y-%m-%dT%H:%M:%OS", tz = "UTC"))
            } else {
              typedef = data_types[[x[3]]]
              stopifnot(!is.null(typedef))

              stdout_list[[x[1]]] <- base64_decode(x[4], what = typedef$type, size = typedef$size)
            }
          } else {
            stop()
          }
        }
      }
    },
    error = function(e) warning(e),
    finally = {
      errors <- process$read_all_error_lines()
      if (length(errors) != 0)
        stop(stringr::str_c("\n", errors, collapse = "\n\n"))
    }
  )

  stdout_list
}

get_process_objects_output <- function(process) {
  stdout_list <- list()

  tryCatch(
    {
      i <- 1
      new_obj <- TRUE
      while (process$is_incomplete_output()) {
        process$poll_io(timeout = 10)

        for (line in process$read_output_lines()) {
          if (new_obj) {
            stdout_list[[i]] <- list()
            new_obj <- FALSE
          }
          if (line == "") {
            i <- i + 1
            new_obj <- TRUE
            next
          }

          x <- stringr::str_split_fixed(line, stringr::coll("\t"), 4)

          stopifnot(all(x[1:3] != ""))

          # R doesnt care if scalar or vector for now
          if (x[2] == "scalar" || x[2] == "vector") {
            if (x[3] == "na_mask") {
              stdout_list[[i]][[x[1]]] <- replace(stdout_list[[x[1]]], !base64_decode(x[4], what = "logical", size = 1), NA)
            } else if (x[3] == "String") {
              stdout_list[[i]][[x[1]]] <- stringr::str_replace_all(stringr::str_split(x[4], stringr::coll("\t"))[[1]], stringr::coll("\\t"), "\t")
            } else if (x[2] == "Date") {
              # date is scalar for now
              date_trunc <- stringr::str_extract(x[4], "^(.*)(?<=\\+00:00)$")
              stopifnot(!is.na(date_trunc))
              stdout_list[[i]][[x[1]]] <- as.POSIXct(strptime(date_trunc, format = "%Y-%m-%dT%H:%M:%OS", tz = "UTC"))
            } else {
              typedef = data_types[[x[3]]]
              stopifnot(!is.null(typedef))

              stdout_list[[i]][[x[1]]] <- base64_decode(x[4], what = typedef$type, size = typedef$size)
            }
          } else {
            stop()
          }
        }
      }
    },
    error = function(e) warning(e),
    finally = {
      errors <- process$read_all_error_lines()
      if (length(errors) != 0)
        stop(stringr::str_c("\n", errors, collapse = "\n\n"))
    }
  )

  stdout_list
}

#' Extract MS file info
#' @export
extract_info <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "info")

  get_process_list_output(process)
}

#' Extract distinct ionization modes used
#' @export
extract_distinct_ionization_modes <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "ionizationmodes")

  get_process_list_output(process)$DistinctIonizationModes
}

#' Extract distinct activation types used
#' @export
extract_distinct_activation_types <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "activationtypes")

  get_process_list_output(process)$DistinctActivationTypes
}

#' Extract distinct ms1 mass analyzers used
#' @export
extract_distinct_ms1_mass_analyzers <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "ms1massanalyzers")

  get_process_list_output(process)$DistinctMs1MassAnalyzers
}

#' Extract distinct ms2 mass analyzers used
#' @export
extract_distinct_ms2_mass_analyzers <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "ms2massanalyzers")

  get_process_list_output(process)$DistinctMs2MassAnalyzers
}

#' Extract Scan Headers
#' @export
extract_scan_headers <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "headers")

  to_df(get_process_list_output(process))
}

#' Extract Full Scan Headers
#' @export
extract_scan_headers_full <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "fullheaders")

  to_df(get_process_list_output(process))
}

#' Extract Scan Extra Headers
#' @export
extract_scan_extra_headers <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "extraheaders")

  to_df(get_process_list_output(process))
}


#' Extract Status Log
#' @export
extract_status_log <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "statuslog")

  to_df(get_process_list_output(process))
}

#' Extract Ms1 Charge State Data
#' @export
extract_ms1_charge_states <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "ms1charges")

  scan_data <- get_process_list_output(process)

  headers_cols <- c("scan_number" = "scan_number", "rt" = "rt", "intensity" = "tic")
  headers_df <- to_df(scan_data[headers_cols])
  names(headers_df) <- names(headers_cols)

  charges_cols <- c("scan_number" = "charges_scan_number", "charge" = "charges_charge", "intensity" = "charges_intensity")
  charges_df <- to_df(scan_data[charges_cols])
  names(charges_df) <- names(charges_cols)

  out_df <- rbind(
    cbind(headers_df[c("scan_number", "rt", "intensity")], charge = NA_real_),
    merge(charges_df, headers_df[c("scan_number", "rt")], by = "scan_number")
  )

  out_df <- out_df[order(out_df$scan_number, out_df$charge), c("scan_number", "rt", "charge", "intensity")]
  row.names(out_df) <- NULL

  out_df

  # dplyr::bind_rows(
  #   headers_df %>%
  #     dplyr::select(scan_number, intensity) %>%
  #     dplyr::mutate(charge = NA_real_),
  #   charges_df
  # ) %>%
  #   dplyr::left_join(
  #     headers_df %>%
  #       dplyr::select(scan_number, rt),
  #     by = "scan_number"
  #   ) %>%
  #   dplyr::arrange(scan_number, charge) %>%
  #   dplyr::select(scan_number, rt, charge, intensity)
}

#' Extract Ms2 scan parent data
#' @export
extract_ms2_parents <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "ms2parents")

  to_df(get_process_list_output(process))
}

#' Extract Ms2 scan parent data
#' @export
extract_profile_scans <- function(filepath, scanNumber = NULL) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath),
    is.null(scanNumber) || is.numeric(scanNumber)
  )

  if (is.null(scanNumber)) {
    process <- start_std_process(filepath, "segmentedscansall")
  } else {
    process <- start_std_process(filepath, "segmentedscansstdin")

    process$write_input(paste0(base64_encode(as.integer(scanNumber)), "\n"))
  }

  get_process_objects_output(process)
}

#' Extract Ms2 scan parent data
#' @export
extract_centroid_scans <- function(filepath, scanNumber = NULL) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath),
    is.null(scanNumber) || is.numeric(scanNumber)
  )

  if (is.null(scanNumber)) {
    process <- start_std_process(filepath, "centroidscansall")
  } else {
    process <- start_std_process(filepath, "centroidscansstdin")

    process$write_input(paste0(base64_encode(as.integer(scanNumber)), "\n"))
  }

  get_process_objects_output(process)
}

#' Extract Ms1 XIC
#' @export
extract_ms1_xic <- function(filepath, ions, tol, tol_mode = "ppm") {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath),
    is.numeric(ions), noNA(ions), all(is.finite(ions)),
    is.number(tol), noNA(tol), tol >= 0,
    is.string(tol_mode)
  )

  process <- start_std_process(filepath, "ms1xic", args = c(tol, tol_mode))

  process$write_input(paste0(base64_encode(as.double(ions)), "\n"))

  get_process_objects_output(process)
}

#' Extract Ms2 XIC
#' @export
extract_ms2_xic <- function(filepath, precursors, transitions, precursor_tol, transition_tol, precursor_tol_mode = "amu", transition_tol_mode = "ppm") {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath),
    is.numeric(precursors), noNA(precursors), all(is.finite(precursors)),
    is.numeric(transitions), noNA(transitions), all(is.finite(transitions)),
    is.number(precursor_tol), noNA(precursor_tol), precursor_tol >= 0,
    is.number(transition_tol), noNA(transition_tol), transition_tol >= 0,
    is.string(precursor_tol_mode),
    is.string(transition_tol_mode)
  )

  process <- start_std_process(filepath, "ms2xic", args = c(precursor_tol, transition_tol, precursor_tol_mode, transition_tol_mode))

  process$write_input(paste0(base64_encode(as.double(precursors)), "\n"))
  process$write_input(paste0(base64_encode(as.double(transitions)), "\n"))

  get_process_objects_output(process)
}

#' Check rawfile conformity
#' @export
check_rawfile_conformity <- function(filepath) {
  enforce_license_accepted()

  assert_that(
    is.string(filepath), file.exists(filepath)
  )

  process <- start_std_process(filepath, "check")

  get_process_list_output(process)
}

# #' Extract Charge Data
# #' @importFrom magrittr `%>%`
# #' @importFrom rlang set_names
# #' @export
# extract_ms1_charge_states_l <- function(filepath) {
#   assert_that(
#     is.string(filepath), file.exists(filepath)
#   )
#
#   process <- start_std_process(filepath, "ms1charges")
#
#   scan_data <- get_process_list_output(process)
#
#   headers_cols <- c("scan_number" = "scan_number", "rt" = "rt", "intensity" = "tic")
#   headers_df <-
#     scan_data[headers_cols] %>%
#     set_names(., names(headers_cols)) %>%
#     tibble::as_tibble()
#
#   charges_cols <- c("scan_number" = "charges_scan_number", "charge" = "charges_charge", "intensity" = "charges_intensity")
#   charges_df <-
#     scan_data[charges_cols] %>%
#     set_names(., names(charges_cols)) %>%
#     tibble::as_tibble()
#
#   dplyr::bind_rows(
#     dplyr::select(headers_df, scan_number, rt, intensity),
#     dplyr::left_join(
#       charges_df,
#       dplyr::select(headers_df, scan_number, rt),
#       by = "scan_number"
#     ),
#   ) %>%
#     dplyr::select(scan_number, rt, charge, intensity) %>%
#     dplyr::arrange(scan_number, charge)
# }

#' @export
get_rawfile_sample_path <- function() system.file("extdata", "sample.raw", package = getPackageName(), mustWork = TRUE)
