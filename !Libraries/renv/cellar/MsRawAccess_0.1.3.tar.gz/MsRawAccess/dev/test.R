library(tidyverse)
library(MsRawAccess)

# rawpath <- "C:/Users/foerstjo/Documents/riemergrp/epitope_prediction/general_MHC_IP_search/160608_MDM_C1R-C0602_BiolRep#1_W_20%_#2_400-650mz_CIDqisOT_25cm90min7s_msms19.raw"
# rawpath <- "C:/Users/foerstjo/Documents/riemergrp/tools_own/rawfile_cli/extract_charges/sample.raw"
# rawpath <- "C:/Users/foerstjo/Documents/riemergrp/data/191219 IP pre-clearing test DDA/QE20191218_005.raw"
# rawpath <- "C:/Users/foerstjo/Documents/riemergrp/data/191220 IP pre-clearing test PRM/QE20191219_010.raw"
# rawpath <- "C:/Users/foerstjo/Documents/riemergrp/epitope_prediction/general_MHC_IP_search/20171201_QEh1_LC1_HLAIp_SA_JMI_3993_R1.raw"
# rawpath <- "C:/Users/foerstjo/Desktop/160608_MDM_C1R-C0602_BiolRep#1_W_20%_#2_400-650mz_CIDqisOT_25cm90min7s_msms19.raw"
# rawpath <- "C:/Users/foerstjo/Desktop/160608_MDM_C1R-C0602_BiolRep#1_W_20%_#2_400-650mz_CIDqisOT_25cm90min7s_msms19.raw"
# rawpath <- "C:/Users/foerstjo/Desktop/160608_MDM_C1R-C0602_BiolRep#1_W_20%_#2_400-650mz_CIDqisOT_25cm90min7s_msms19.raw"
rawpath <- "C:/Users/foerstjo/Documents/riemergrp/tools_own/example_rawfiles/QE20200313_002.raw"

extract_info(rawpath)

extract_distinct_ionization_modes(rawpath)

extract_distinct_activation_types(rawpath)

extract_distinct_ms1_mass_analyzers(rawpath)

extract_distinct_ms2_mass_analyzers(rawpath)

extract_ms1_charge_states(rawpath) %>% as_tibble()

cbind(
  extract_scan_headers(rawpath),
  extract_ms2_parents(rawpath)[-1],
  extract_scan_extra_headers(rawpath)[-1]
) %>% as_tibble()

extract_scan_headers_full(rawpath) %>% as_tibble()

extract_status_log(rawpath) %>% as_tibble()

extract_centroid_scans(rawpath, 1L)

extract_ms1_xic(rawpath, ions = 400, tol = 5, tol_mode = "ppm")

extract_ms2_xic(rawpath, precursors = c(400, 400, 500), transitions = c(600, 650, 600), precursor_tol = 2, transition_tol = 5000, transition_tol_mode = "ppm")

check_rawfile_conformity(rawpath)

