#' TICtools
#'
#' Color tics etc
#'
#' @import assertthat
#' @import purrr
#' @import grid
#' @importFrom rlang .data
"_PACKAGE"

#' Extract Charge Data
#' @export
extract_charge_data <- MsRawAccess::extract_ms1_charge_states

#' Plot Charge Data
#' @export
plot_charge_data <- function(charges_df, facets = c(), max_charge = NA, color_log = TRUE, facet_free_y = FALSE, invert_stacking = FALSE, na_color = "darkred", rasterize = FALSE) {
  charges_df <- tibble::tibble(charges_df)
  facets_chr <- unname(tidyselect::vars_select(names(charges_df), {{ facets }}))
  facets_syms <- rlang::syms(facets_chr)

  charges_df <- dplyr::select(charges_df, {{ facets }}, scan_number, rt, charge, intensity)

  rows_tic <- is.na(charges_df$charge)

  headers_df <- dplyr::select(charges_df[rows_tic, ], -charge)
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  scale_fill_trans <- if (color_log) "log10" else "identity"

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)

    scale_fill <- ggplot2::scale_fill_viridis_c(
      na.value = na_color,
      trans = scale_fill_trans
    )
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))

    scale_fill <- ggplot2::scale_fill_viridis_c(
      limits = c(1, max_charge),
      breaks = c(1:max_charge),
      labels = c(
        seq(max_charge - 1),
        paste0(">=", max_charge)
      ),
      na.value = na_color,
      trans = scale_fill_trans
    )
  }

  facet_scales <- if (facet_free_y) "free_y" else "fixed"

  stacking <- if (invert_stacking) position_stack(reverse = TRUE) else position_stack(reverse = FALSE)

  if (isFALSE(rasterize))
    try_rasterize <- force
  else if (isTRUE(rasterize))
    try_rasterize <- ggrastr::rasterize
  else if (is.list(rasterize))
    try_rasterize <- partial(ggrastr::rasterize, !!!rasterize)
  else
    stop()

  if (length(facets_syms) > 0)
    join_fun <- partial(dplyr::full_join, by = dplyr::join_by(!!!facets_syms), relationship = "many-to-many")
  else
    join_fun <- dplyr::cross_join

  headers_df %>%
    dplyr::select({{ facets }}, scan_number, rt) %>%
    join_fun(dplyr::reframe(charges_df, .by = {{ facets }}, charge = unique(charge))) %>%
    dplyr::left_join(
      charges_df,
      by = dplyr::join_by(!!!facets_syms, scan_number, charge),
      relationship = "one-to-one"
    ) %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    ggplot2::ggplot(ggplot2::aes(x = rt, y = intensity)) +
    ggplot2::facet_grid(rows = ggplot2::vars(!!!facets_syms), scales = facet_scales) +
    ggplot2::geom_hline(yintercept = 0, color = "black", alpha = 0.3) +
    try_rasterize(ggplot2::geom_area(data = headers_df, aes(fill = NA_real_))) +
    try_rasterize(ggplot2::geom_area(ggplot2::aes(fill = charge, group = charge), position = stacking)) +
    scale_fill +
    ggplot2::labs(x = "Retention Time (min)", y = "Total Ion Current (a. u.)", fill = "Charge State")
}

#' Plot Charge Data without facets
#' @export
plot_charge_data_nofacet <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred", rasterize = FALSE) {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- charges_df[!rows_tic, ]

  scale_fill_trans <- if (color_log) "log10" else "identity"

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)

    scale_fill <- ggplot2::scale_fill_viridis_c(
      na.value = na_color,
      trans = scale_fill_trans
    )
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))

    scale_fill <- ggplot2::scale_fill_viridis_c(
      limits = c(1, max_charge),
      breaks = c(1:max_charge),
      labels = c(
        seq(max_charge - 1),
        paste0(">=", max_charge)
      ),
      na.value = na_color,
      trans = scale_fill_trans
    )
  }

  charge_template <- seq_len(max_charge)

  stacking <- if (invert_stacking) position_stack(reverse = TRUE) else position_stack(reverse = FALSE)

  if (isFALSE(rasterize))
    try_rasterize <- force
  else if (isTRUE(rasterize))
    try_rasterize <- ggrastr::rasterize
  else if (is.list(rasterize))
    try_rasterize <- partial(ggrastr::rasterize, !!!rasterize)
  else
    stop()

  charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = charge_template)) %>%
    dplyr::left_join(
      dplyr::select(charges_df, scan_number, charge, intensity),
      by = dplyr::join_by(scan_number, charge),
      relationship = "one-to-one"
    ) %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    ggplot2::ggplot(ggplot2::aes(x = rt, y = intensity)) +
    ggplot2::geom_hline(yintercept = 0, color = "black", alpha = 0.3) +
    try_rasterize(ggplot2::geom_area(data = charges_df_tic, aes(fill = NA_real_))) +
    try_rasterize(ggplot2::geom_area(ggplot2::aes(fill = charge, group = charge), position = stacking)) +
    scale_fill +
    ggplot2::labs(x = "Retention Time (min)", y = "Total Ion Current (a. u.)", fill = "Charge State")
}

#' Plot Charge Data using Base plots
#' @export
plot_charge_data_base <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred") {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rt_range <- range(charges_df$rt)
  rt_min <- rt_range[1]
  rt_max <- rt_range[2]
  tic_max <- max(charges_df$intensity)

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))
  }

  charge_template <- seq_len(max_charge)
  charge_template_stacking_order <- if (invert_stacking) charge_template else rev(charge_template)

  charges_df <-
    charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = charge_template_stacking_order)) %>%
    dplyr::left_join(charges_df, by = dplyr::join_by(scan_number, charge), relationship = "one-to-one") %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    dplyr::mutate(.by = scan_number, intensity = cumsum(intensity)) %>%
    dplyr::mutate(plot_order = if (invert_stacking) -charge else charge)

  scale_fill_trans_fun <- if (color_log) log10 else {function(x) x - 1}

  if (length(charge_template) == 1) {
    color_trans <- 0.5
  } else {
    color_trans <- scale_fill_trans_fun(charge_template)
    color_trans <- color_trans / dplyr::last(color_trans)
  }
  color_matrix <- colorRamp(viridisLite::viridis(256))(color_trans)
  color_palette <- apply(color_matrix, 1, function(x) rgb(x[1], x[2], x[3], maxColorValue = 255))

  plot(range(charges_df_tic$rt), c(0, tic_max), type = 'n', xlab = "X", ylab = "Y")
  polygon(c(charges_df_tic$rt, rt_max, rt_min), c(charges_df_tic$intensity, 0, 0), col = na_color, border = NA)
  charges_df %>%
    dplyr::group_by(plot_order, charge) %>%
    dplyr::group_walk(~ polygon(c(.x$rt, rt_max, rt_min), c(.x$intensity, 0, 0), col = color_palette[.y$charge], border = NA))

  invisible()
}

#' Plot Charge Data using Base plots
#' @export
plot_charge_data_grid <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred") {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rt_range <- range(charges_df$rt)
  rt_min <- rt_range[1]
  rt_max <- rt_range[2]
  tic_max <- max(charges_df$intensity)

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))
  }

  charge_template <- seq_len(max_charge)
  charge_template_stacking_order <- if (invert_stacking) charge_template else rev(charge_template)

  charges_df <-
    charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = charge_template_stacking_order)) %>%
    dplyr::left_join(charges_df, by = dplyr::join_by(scan_number, charge), relationship = "one-to-one") %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    dplyr::mutate(.by = scan_number, intensity = cumsum(intensity)) %>%
    dplyr::mutate(plot_order = if (invert_stacking) -charge else charge)

  scale_fill_trans_fun <- if (color_log) log10 else {function(x) x - 1}

  if (length(charge_template) == 1) {
    color_trans <- 0.5
  } else {
    color_trans <- scale_fill_trans_fun(charge_template)
    color_trans <- color_trans / dplyr::last(color_trans)
  }
  color_matrix <- colorRamp(viridisLite::viridis(256))(color_trans)
  color_palette <- apply(color_matrix, 1, function(x) rgb(x[1], x[2], x[3], maxColorValue = 255))

  poly_00 <- function(x, y, xmax, color, vp) polygonGrob(c(x, xmax, 0), c(y, 0, 0), default.units = "native", gp = gpar(fill = color, lty = "blank"), vp = vp)
  # plot(range(charges_df_tic$rt), c(0, tic_max), type='n', xlab="X", ylab="Y")
  x <- c(charges_df_tic$rt, rt_max, rt_min)
  y <- c(charges_df_tic$intensity, 0, 0)
  vp <- viewport(
    x = 0.5,
    y = 0.5,
    width = 0.85,
    height = 0.85,
    just = c("center"),
    xscale = extendrange(x),
    yscale = extendrange(y)
  )
  rlang::exec(gList,
    xaxisGrob(vp = vp),
    yaxisGrob(vp = vp),
    # polygonGrob(c(1, 80, 100), c(1, 6e9, 2e9), gp = gpar(fill = na_color, lty = "blank"), vp = vp)
    poly_00(charges_df_tic$rt, charges_df_tic$intensity, rt_max, na_color, vp),
    !!!(
      charges_df %>%
      dplyr::group_by(plot_order, charge) %>%
      dplyr::group_map(~ poly_00(.x$rt, .x$intensity, rt_max, color_palette[.y$charge], vp))
    )
  )
}

#' Plot Charge Data using Base plots
#' @export
plot_charge_data_groblist <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred") {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rt_range <- range(charges_df$rt)
  rt_min <- rt_range[1]
  rt_max <- rt_range[2]
  tic_max <- max(charges_df$intensity)

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))
  }

  charge_template <- seq_len(max_charge)
  charge_template_stacking_order <- if (invert_stacking) charge_template else rev(charge_template)

  charges_df <-
    charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = charge_template_stacking_order)) %>%
    dplyr::left_join(charges_df, by = dplyr::join_by(scan_number, charge), relationship = "one-to-one") %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    dplyr::mutate(.by = scan_number, intensity = cumsum(intensity)) %>%
    dplyr::mutate(plot_order = if (invert_stacking) -charge else charge)

  scale_fill_trans_fun <- if (color_log) log10 else {function(x) x - 1}

  if (length(charge_template) == 1) {
    color_trans <- 0.5
  } else {
    color_trans <- scale_fill_trans_fun(charge_template)
    color_trans <- color_trans / dplyr::last(color_trans)
  }
  color_matrix <- colorRamp(viridisLite::viridis(256))(color_trans)
  color_palette <- apply(color_matrix, 1, function(x) rgb(x[1], x[2], x[3], maxColorValue = 255))

  poly_00 <- function(x, y, xmax, color, vp) polygonGrob(c(x, xmax, 0), c(y, 0, 0), default.units = "native", gp = gpar(fill = color, lty = "blank"))

  c(
    list(
      poly_00(charges_df_tic$rt, charges_df_tic$intensity, rt_max, na_color)
    ),
    charges_df %>%
      dplyr::group_by(plot_order, charge) %>%
      dplyr::group_map(~ poly_00(.x$rt, .x$intensity, rt_max, color_palette[.y$charge]))
  )
}

#' Plot Charge Data using ggplot annotation with grob
#' @export
plot_charge_data_gggrob <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred", rasterize = FALSE) {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rt_range <- range(charges_df$rt)
  rt_min <- rt_range[1]
  rt_max <- rt_range[2]
  tic_max <- max(charges_df$intensity)

  charges_df <- dplyr::mutate(charges_df,
    rt = (rt - rt_min) / (rt_max - rt_min),
    intensity = intensity / tic_max
  )

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  if (color_log) {
    scale_fill_trans <- "log10"
    scale_fill_trans_fun <- log10
  } else {
    scale_fill_trans <- "identity"
    scale_fill_trans_fun <- function(x) x - 1
  }

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)

    scale_fill <- ggplot2::scale_fill_viridis_c(
      limits = c(1, max_charge),
      # breaks = 1:max_charge,
      # labels = 1:max_charge,
      na.value = na_color,
      trans = scale_fill_trans
    )
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))

    scale_fill <- ggplot2::scale_fill_viridis_c(
      limits = c(1, max_charge),
      breaks = 1:max_charge,
      labels = c(
        seq_len(max_charge - 1),
        paste0(">=", max_charge)
      ),
      na.value = na_color,
      trans = scale_fill_trans
    )
  }

  charge_template <- seq_len(max_charge)
  charge_template_stacking_order <- if (invert_stacking) charge_template else rev(charge_template)

  charges_df_list <-
    charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = if (invert_stacking) charge_template else rev(charge_template))) %>%
    dplyr::left_join(charges_df, by = dplyr::join_by(scan_number, charge), relationship = "one-to-one") %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    dplyr::mutate(.by = scan_number, intensity = cumsum(intensity)) %>%
    dplyr::select(-scan_number) %>%
    dplyr::group_by(charge) %>%
    # the split dfs will be sorted by the grouping (charge)
    dplyr::group_split(.keep = FALSE)

  if (length(charge_template) == 1) {
    color_trans <- 0.5
  } else {
    color_trans <- scale_fill_trans_fun(charge_template)
    color_trans <- color_trans / dplyr::last(color_trans)
  }
  color_matrix <- colorRamp(viridisLite::viridis(256))(color_trans)
  color_palette <- apply(color_matrix, 1, function(x) rgb(x[1], x[2], x[3], maxColorValue = 255))

  if (isFALSE(rasterize))
    try_rasterize <- force
  else if (isTRUE(rasterize))
    try_rasterize <- ggrastr::rasterize
  else if (is.list(rasterize))
    try_rasterize <- partial(ggrastr::rasterize, !!!rasterize)
  else
    stop()

  poly_00 <- function(x, y, color) polygonGrob(c(x, 1, 0), c(y, 0, 0), default.units = "native", gp = gpar(fill = color, lty = "blank"))
  annotate_poly_00 <- function(x, y, color) ggplot2::annotation_custom(grob = poly_00(x, y, color), xmin = rt_min, xmax = rt_max, ymin = 0, ymax = tic_max)

  ggp <- ggplot2::ggplot(data = data.frame(fill = numeric()), ggplot2::aes(fill = fill)) +
    ggplot2::geom_point() +
    ggplot2::geom_hline(yintercept = 0, color = "black", alpha = 0.3) +
    try_rasterize(annotate_poly_00(charges_df_tic$rt, charges_df_tic$intensity, na_color))

  # we know that dfs in charges_df_list are ordered 1:N
  # if stacking is inverted, we want to plot highest first
  order_func <- if (invert_stacking) rev else force
  for (charge in order_func(seq_along(charges_df_list))) {
    df <- charges_df_list[[charge]]
    ggp <- ggp + try_rasterize(annotate_poly_00(df$rt, df$intensity, color_palette[charge]))
  }

  ggp <-
    ggp +
    scale_fill +
    ggplot2::labs(x = "Retention Time (min)", y = "Total Ion Current (a. u.)", fill = "Charge State")

  list(
    plot = ggp,
    rt_range = rt_range,
    tic_max = tic_max
  )
}

#' Plot Charge Data using geom_polygon
#' @export
plot_charge_data_ggpoly <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred", rasterize = FALSE) {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rt_range <- range(charges_df$rt)
  rt_min <- rt_range[1]
  rt_max <- rt_range[2]
  tic_max <- max(charges_df$intensity)

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  scale_fill_trans <- if (color_log) "log10" else "identity"

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)

    scale_fill <- ggplot2::scale_fill_viridis_c(
      # limits = c(1, max_charge),
      # breaks = 1:max_charge,
      # labels = 1:max_charge,
      na.value = na_color,
      trans = scale_fill_trans
    )
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))

    scale_fill <- ggplot2::scale_fill_viridis_c(
      limits = c(1, max_charge),
      breaks = 1:max_charge,
      labels = c(
        seq_len(max_charge - 1),
        paste0(">=", max_charge)
      ),
      na.value = na_color,
      trans = scale_fill_trans
    )
  }

  charge_template <- seq_len(max_charge)
  charge_template_stacking_order <- if (invert_stacking) charge_template else rev(charge_template)

  charges_df_list <-
    charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = charge_template_stacking_order)) %>%
    dplyr::left_join(charges_df, by = dplyr::join_by(scan_number, charge), relationship = "one-to-one") %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    dplyr::mutate(.by = scan_number, intensity = cumsum(intensity)) %>%
    dplyr::select(-scan_number) %>%
    dplyr::group_by(charge) %>%
    # the split dfs will be sorted by the grouping (charge)
    dplyr::group_split(.keep = FALSE)

  if (isFALSE(rasterize))
    try_rasterize <- force
  else if (isTRUE(rasterize))
    try_rasterize <- ggrastr::rasterize
  else if (is.list(rasterize))
    try_rasterize <- partial(ggrastr::rasterize, !!!rasterize)
  else
    stop()

  close_polygon <- function(df) dplyr::bind_rows(df, list(rt = c(rt_max, rt_min), intensity = c(0, 0)))

  ggp <-
    charges_df_tic %>%
    close_polygon() %>%
    ggplot2::ggplot(aes(x = rt, y = intensity)) +
    scale_fill +
    ggplot2::geom_hline(yintercept = 0, color = "black", alpha = 0.3) +
    ggplot2::geom_polygon(aes(fill = NA_real_))

  # we know that dfs in charges_df_list are ordered 1:N
  # if stacking is inverted, we want to plot highest first
  for (charge in rev(charge_template_stacking_order)) {
    ggp <- ggp + try_rasterize(ggplot2::geom_polygon(data = close_polygon(charges_df_list[[charge]]), aes(fill = !!charge)))
  }

  ggp <-
    ggp +
    ggplot2::labs(x = "Retention Time (min)", y = "Total Ion Current (a. u.)", fill = "Charge State")

  list(
    plot = ggp,
    rt_range = rt_range,
    tic_max = tic_max
  )
}

#' Plot Charge Data using combined geom_polygon
#' @export
plot_charge_data_ggunipoly <- function(charges_df, max_charge = NA, color_log = TRUE, invert_stacking = FALSE, na_color = "darkred", rasterize = FALSE) {
  charges_df <- tibble::tibble(charges_df)
  charges_df <- dplyr::select(charges_df, scan_number, rt, charge, intensity)

  rt_range <- range(charges_df$rt)
  rt_min <- rt_range[1]
  rt_max <- rt_range[2]
  tic_max <- max(charges_df$intensity)

  rows_tic <- is.na(charges_df$charge)

  charges_df_tic <- charges_df[rows_tic, ]
  charges_df <- dplyr::select(charges_df[!rows_tic, ], -rt)

  scale_fill_trans <- if (color_log) "log10" else "identity"

  if (is.na(max_charge)) {
    max_charge <- max(charges_df$charge)

    scale_fill <- ggplot2::scale_fill_viridis_c(
      # limits = c(1, max_charge),
      # breaks = 1:max_charge,
      # labels = 1:max_charge,
      na.value = na_color,
      trans = scale_fill_trans
    )
  } else {
    charges_df <-
      charges_df %>%
      dplyr::mutate(charge = replace(charge, charge > max_charge, max_charge)) %>%
      dplyr::summarise(.by = -intensity, intensity = sum(intensity))

    scale_fill <- ggplot2::scale_fill_viridis_c(
      limits = c(1, max_charge),
      breaks = 1:max_charge,
      labels = c(
        seq_len(max_charge - 1),
        paste0(">=", max_charge)
      ),
      na.value = na_color,
      trans = scale_fill_trans
    )
  }

  charge_template <- seq_len(max_charge)
  charge_template_stacking_order <- if (invert_stacking) charge_template else rev(charge_template)

  charges_df <-
    charges_df_tic %>%
    dplyr::select(scan_number, rt) %>%
    dplyr::cross_join(tibble::tibble(charge = charge_template_stacking_order)) %>%
    dplyr::left_join(charges_df, by = dplyr::join_by(scan_number, charge), relationship = "one-to-one") %>%
    tidyr::replace_na(list(intensity = 0)) %>%
    dplyr::mutate(.by = scan_number, intensity = cumsum(intensity)) %>%
    dplyr::bind_rows(charges_df_tic) %>%
    dplyr::select(-scan_number) %>%
    dplyr::reframe(.by = charge, rt = c(rt, rt_max, rt_min), intensity = c(intensity, 0, 0)) %>%
    dplyr::mutate(group = factor(charge, levels = c(NA_character_, rev(charge_template_stacking_order)), exclude = character()))

  if (isFALSE(rasterize))
    try_rasterize <- force
  else if (isTRUE(rasterize))
    try_rasterize <- ggrastr::rasterize
  else if (is.list(rasterize))
    try_rasterize <- partial(ggrastr::rasterize, !!!rasterize)
  else
    stop()

  ggp <-
    ggplot2::ggplot(data = charges_df, aes(x = rt, y = intensity)) +
    scale_fill +
    ggplot2::geom_hline(yintercept = 0, color = "black", alpha = 0.3) +
    try_rasterize(ggplot2::geom_polygon(aes(fill = charge, group = group))) +
    ggplot2::labs(x = "Retention Time (min)", y = "Total Ion Current (a. u.)", fill = "Charge State")

  list(
    plot = ggp,
    rt_range = rt_range,
    tic_max = tic_max
  )
}
